 
Ces 2 fichiers "instruments.inx" et "instruments.py" doivent être placés dans le dossier "~/.inkscape/extensions" (à créer si besoin).

Dans Inkscape, aller au menu "effects -> Exemples -> Instruments".

Les graduations du rapporteur sont mal placées et doivent donc être remises en place...





This 2 files "instruments.inx" and "instruments.py" must be placed in "~/.inkscape/extensions" directory (to be created if need be).

In Inkscape, go to "effects -> Exemples -> Instruments" menu.

The Protractor graduations are badly placed and must be replaced...


